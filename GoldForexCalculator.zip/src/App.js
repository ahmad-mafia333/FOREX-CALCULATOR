import React from "react";
import ForexCalculator from "./ForexCalculator";
import "./App.css";

export default function App() {
  return (
    <div className="app-container">
      <header className="header">
        <h1>Forex Gold Trade Calculator</h1>
        <p className="subheading">Designed by <strong>M Ahmad Anwar</strong></p>
      </header>
      <main>
        <ForexCalculator />
      </main>
      <footer className="footer">
        &copy; {new Date().getFullYear()} M Ahmad Anwar | All Rights Reserved
      </footer>
    </div>
  );
}
