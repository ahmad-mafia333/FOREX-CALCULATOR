import React, { useState } from "react";

export default function ForexCalculator() {
  const [entryPrice, setEntryPrice] = useState(2300);
  const [balance, setBalance] = useState(1000);
  const [riskPercent, setRiskPercent] = useState(2);

  const riskAmount = (balance * riskPercent) / 100;
  const stopLossPrice = entryPrice - 10;
  const takeProfitPrice = entryPrice + 20;
  const slPips = 100;
  const tpPips = 200;
  const lotSize = riskAmount / slPips;
  const profitAtTP = lotSize * tpPips;

  return (
    <div className="calculator-container">
      <h2>Trade Settings</h2>
      <div className="form-group">
        <label>Entry Price</label>
        <input
          type="number"
          value={entryPrice}
          onChange={(e) => setEntryPrice(parseFloat(e.target.value))}
        />
      </div>
      <div className="form-group">
        <label>Account Balance ($)</label>
        <input
          type="number"
          value={balance}
          onChange={(e) => setBalance(parseFloat(e.target.value))}
        />
      </div>
      <div className="form-group">
        <label>Risk per Trade (%)</label>
        <input
          type="number"
          value={riskPercent}
          onChange={(e) => setRiskPercent(parseFloat(e.target.value))}
        />
      </div>

      <h2>Trade Output</h2>
      <div className="results">
        <p><strong>Risk Amount:</strong> ${riskAmount.toFixed(2)}</p>
        <p><strong>Stop Loss Price:</strong> ${stopLossPrice.toFixed(2)}</p>
        <p><strong>Take Profit Price:</strong> ${takeProfitPrice.toFixed(2)}</p>
        <p><strong>Lot Size:</strong> {lotSize.toFixed(2)} lots</p>
        <p><strong>Estimated Profit at TP:</strong> ${profitAtTP.toFixed(2)}</p>
        <p><strong>Risk : Reward</strong> 1 : {(profitAtTP / riskAmount).toFixed(2)}</p>
      </div>
    </div>
  );
}
